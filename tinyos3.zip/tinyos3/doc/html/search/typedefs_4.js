var searchData=
[
  ['mutex_569',['Mutex',['../group__syscalls.html#gaef2ec62cae8e0031fd19fc8b91083ade',1,'tinyos.h']]]
];
