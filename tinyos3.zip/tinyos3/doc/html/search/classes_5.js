var searchData=
[
  ['logrec_338',['logrec',['../structlogrec.html',1,'']]]
];
