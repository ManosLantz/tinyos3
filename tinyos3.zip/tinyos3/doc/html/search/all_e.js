var searchData=
[
  ['open_182',['Open',['../structfile__operations.html#a2732da2af03e1fc7ba0b63a529ab1411',1,'file_operations']]],
  ['openinfo_183',['OpenInfo',['../group__syscalls.html#gaf326b11574cdc84a9e21b9d860076821',1,'tinyos.h']]],
  ['opennull_184',['OpenNull',['../group__syscalls.html#ga39805b4ae668b715fb43f0f1e6ce8c45',1,'tinyos.h']]],
  ['openterminal_185',['OpenTerminal',['../group__syscalls.html#ga6ea2b586a8dfcfc1e7065e1664a0fb35',1,'tinyos.h']]],
  ['owner_5fpcb_186',['owner_pcb',['../structthread__control__block.html#a74aa312623cb8be2bc719d5210b58c04',1,'thread_control_block']]]
];
