
#include "tinyos.h"
#include "kernel_dev.h"
#include "kernel_sched.h"
#include "kernel_streams.h"



#include "kernel_proc.h"
#include "kernel_cc.h"

#include "stdio.h"

static file_ops file_reader = {
	.Open = (void*) NULL,
	.Read = (void*) pipe_read,
	.Write = (void*) -1,
	.Close = (void*) pipe_reader_close
};


static file_ops file_writer = {
	.Open = (void*) NULL,
	.Read = (void*) -1,
	.Write = (void*) pipe_write,
	.Close = (void*) pipe_writer_close
};


int pipe_writer_close (void* picb){
	pipe_cb *pipecb= (pipe_cb *) picb;
	pipecb->w=NULL;

	if(pipecb->r==NULL){
		free(pipecb);
	}else{
		kernel_broadcast (&pipecb->has_space);
	}

	return 0;
}


int pipe_reader_close (void* picb){

	//printf("\n\n\n\n\n\n\nmpaino se pipe reader close");
	pipe_cb *pipecb= (pipe_cb*) picb;
	pipecb->r=NULL;

	if(pipecb->w==NULL){
		free(pipecb);
	}else{
		kernel_broadcast (&pipecb->has_data);
	}

	return 0;
}





int sys_Pipe(pipe_t* pipe)
{
	FCB* fcbs[2];
	Fid_t fids[2];


	if(FCB_reserve(2,fids,fcbs)==0) return -1;
		
	


	pipe_cb* picb = (pipe_cb*) xmalloc (sizeof(pipe_cb));
	picb->has_space = COND_INIT;
	picb->has_data = COND_INIT;
	picb->r_position=0;
	picb->w_position=0;
	picb->r= fcbs[0];
	picb->w= fcbs[1]; 
	pipe->read = fids[0];
	pipe->write = fids[1];






	fcbs[0]->streamobj = picb;
	fcbs[1]->streamobj = picb;

	fcbs[0]->streamfunc = &file_reader;
	fcbs[1]->streamfunc = &file_writer;

	return 0;



}




int pipe_write(void* pipecb_t, const char *buf, unsigned int size)
{

 //printf("\n\n\n\n\n\n\n%alahakbar\n\n\n\n\n");
pipe_cb* picb = (pipe_cb*) pipecb_t;	
if (picb == NULL) return -1;

if (picb->BUFFER == NULL) return -1;


if (buf == NULL) return -1;


if (picb->w == NULL || picb->r ==NULL) return -1;


int i = 0;

while (picb->current_pipe_bytes == PIPE_BUFFER_SIZE && picb->r != NULL)
{    //oso ta bytes pou uparxoun einai isa me to buffsize kane wait, diladi an den mporei na grapsei alla
	kernel_wait(&picb->has_space,SCHED_PIPE);
}
if(picb->r == NULL) return -1;

while (i < size && picb->current_pipe_bytes < PIPE_BUFFER_SIZE)
{ //loop gia grapsimo

	picb->BUFFER[picb->w_position] = buf[i];
	picb->w_position++;
	i++;
	picb->current_pipe_bytes++;

	if (picb->w_position == PIPE_BUFFER_SIZE) picb->w_position = 0; // sunthiki gia epistrofi stin arxi an ftasei o writter sto max buf size
		
		
}
	

kernel_broadcast(&picb->has_data); //ksipnima ton reader

return i;
}



int pipe_read(void* pipecb_t, char *buf, unsigned int size)
{


	pipe_cb* picb = (pipe_cb*) pipecb_t;

	if (picb == NULL) return -1;

	if (picb->BUFFER == NULL) return -1;
	
	if (buf == NULL) return -1;
	


	
	 

	while (((picb->current_pipe_bytes == 0 && picb->w != NULL ))){ //oso uparxoun mesa bytes h oso den uparxoun kai o writter einai null kane wait.
		kernel_wait(&picb->has_data,SCHED_PIPE);
	}


	if (picb->current_pipe_bytes == 0 ){ // ean den uparxoun mesa bytes kai o writter einai null kane return.
		return 0;
	}
	

	uint fl = (picb->current_pipe_bytes<size) ? picb->current_pipe_bytes : size;  //epilogi tou mikroterou anamesa sta bytes pou uparxoun mesa kai sto size pou thelei na diabasoume.
	
	int i = 0;

	while (i < fl && i<	PIPE_BUFFER_SIZE)
	{  // loop gia diabasma
		buf[i] = picb->BUFFER[picb->r_position];
		picb->r_position++;

		i++;
		picb->current_pipe_bytes--;  

		if (picb->r_position== PIPE_BUFFER_SIZE)
		{ // sunthiki gia epistrofi stin arxi an ftasei o reader sto max buf size
			picb->r_position= 0;
		}	

	}
	


	kernel_broadcast(&picb->has_space); //ksipnima ton writer

	return i;
}


